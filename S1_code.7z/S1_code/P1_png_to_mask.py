import os
import json
import cv2
import pandas as pd
import shutil

class ImageMaskProcessor:
    def __init__(self, excel_path, base_dir, output_dir, prefixes):
        self.excel_path = excel_path
        self.base_dir = base_dir
        self.output_dir = output_dir
        self.prefixes = prefixes
        self.df = pd.read_excel(excel_path)
        self.filtered_df = self._filter_dataframe()
        os.makedirs(output_dir, exist_ok=True)

    def _filter_dataframe(self):
        # 筛选数据框，匹配前缀
        filtered_df = self.df[~self.df['names'].str.startswith(tuple(self.prefixes))]
        return filtered_df

    def _generate_paths(self, row):
        # 获取相对路径，去掉前导斜杠
        fundus_path = row['fundus'].lstrip('/')
        mask_path = row['fundus_od_seg'].lstrip('/')

        # 拼接原始路径
        original_fundus_path = os.path.normpath(os.path.join(self.base_dir, fundus_path))
        original_mask_path = os.path.normpath(os.path.join(self.base_dir, mask_path))

        # 调试打印路径，查看拼接后的结果是否正确
        print(f"Original fundus path: {original_fundus_path}")
        print(f"Original mask path: {original_mask_path}")

        # 检查文件是否存在
        if not os.path.exists(original_fundus_path):
            print(f"Warning: Fundus image not found at {original_fundus_path}")
        if not os.path.exists(original_mask_path):
            print(f"Warning: Mask image not found at {original_mask_path}")

        mask_name = os.path.basename(original_mask_path)
        json_name = os.path.splitext(mask_name)[0] + ".json"

        # 生成新的路径
        new_image_path = os.path.join(self.output_dir, "images", mask_name)
        new_mask_path = os.path.join(self.output_dir, "masks", mask_name)
        new_json_path = os.path.join(self.output_dir, "json", json_name)

        # 确保目录存在
        os.makedirs(os.path.dirname(new_image_path), exist_ok=True)
        os.makedirs(os.path.dirname(new_mask_path), exist_ok=True)
        os.makedirs(os.path.dirname(new_json_path), exist_ok=True)

        return {
            "original_fundus_path": original_fundus_path,
            "original_mask_path": original_mask_path,
            "new_image_path": new_image_path,
            "new_mask_path": new_mask_path,
            "new_json_path": new_json_path,
            "names": row['names']
        }

    def mask_to_labelme(self, fundus_path, mask_path, output_path):
        # 读取黑白mask图像
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise ValueError(f"Could not read the mask image from {mask_path}")

        # 查找mask图像中的轮廓
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 构建Labelme JSON格式的基础结构
        labelme_data = {
            "version": "5.5.0",
            "flags": {},
            "shapes": [],
            "imagePath": fundus_path,
            "imageData": None,
            "imageHeight": mask.shape[0],
            "imageWidth": mask.shape[1]
        }

        # 处理每个轮廓
        for contour in contours:
            # 确保轮廓点是一个列表且包含 [x, y] 格式
            contour_points = contour.squeeze().tolist()
            if not isinstance(contour_points[0], list):
                contour_points = [contour_points]

            # 转换所有点的坐标为浮点数
            points = [[float(point[0]), float(point[1])] for point in contour_points]

            shape = {
                "label": "optic_disc",
                "points": points,
                "group_id": None,
                "description": "",
                "shape_type": "polygon",
                "flags": {},
                "mask": None
            }
            labelme_data["shapes"].append(shape)

        # 将Labelme数据保存为JSON文件，缩进为2个空格
        with open(output_path, 'w') as json_file:
            json.dump(labelme_data, json_file, indent=2)

    def process_images(self):
        # 用于存储新的路径信息
        new_records = []

        # 遍历筛选后的数据框并处理
        for _, row in self.filtered_df.iterrows():
            paths = self._generate_paths(row)

            # 复制原始图像和mask到新路径
            shutil.copy2(paths['original_fundus_path'], paths['new_image_path'])
            shutil.copy2(paths['original_mask_path'], paths['new_mask_path'])

            # 生成对应的Labelme JSON文件
            self.mask_to_labelme(paths['original_fundus_path'], paths['original_mask_path'], paths['new_json_path'])

            # 记录新的文件路径信息
            new_records.append({
                "names": paths['names'],
                "original_fundus": paths['original_fundus_path'],
                "original_mask": paths['original_mask_path'],
                "new_image_path": paths['new_image_path'],
                "new_mask_path": paths['new_mask_path'],
                "new_json_path": paths['new_json_path']
            })

        # 创建新的Excel文件并写入新的路径信息
        new_excel_path = os.path.join(self.output_dir, "processed_data_summary.xlsx")
        new_df = pd.DataFrame(new_records)
        new_df.to_excel(new_excel_path, index=False)

        print(f"处理完成，所有文件已保存，新Excel文件路径为：{new_excel_path}")

# 使用示例
if __name__ == "__main__":
    # 定义参数
    excel_path = r"E:\DeepLearning\SMDG\SMDG_metadata.xlsx"  # Excel文件路径
    base_dir = r"E:\DeepLearning\SMDG\SMDG_full_data"  # 根目录，包含所有相对路径的基础路径
    output_dir = r"E:\DeepLearning\Session_1_seg_for_od\S0_data\P1_data"  # 处理后的文件保存路径
    prefixes = ['PAPILA']  # 要筛选的前缀

    # 实例化类并调用处理函数
    processor = ImageMaskProcessor(excel_path, base_dir, output_dir, prefixes)
    processor.process_images() 

    
    ###labelme E:\DeepLearning\Session_1_seg_for_od\S0_data\P1_data\images  --labels E:\DeepLearning\Session_1_seg_for_od\S0_data\P0_data\label.txt --nodata --autosave --output E:\DeepLearning\Session_1_seg_for_od\S0_data\P1_data\json
    # 实例化类并调用处理函数

#labelme C:/Users/ZhengYong/Desktop --labels E:/DeepLearning/Session_1_seg_for_od/S0_data/P0_data/label.txt --nodata --autosave --output C:/Users/ZhengYong/Desktop 
