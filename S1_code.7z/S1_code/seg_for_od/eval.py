import os
import time
import torch
import numpy as np
import cv2
from tqdm import tqdm
from operator import add
from model import build_unet
from utils import seeding, mask_parse, calculate_metrics, calculate_confusion_matrix, AUCCalculator

class UNetEvaluator:
    def __init__(self, test_x, test_y, checkpoint_path, results_dir, img_height, img_width, seed):
        # Set parameters
        self.test_x = test_x
        self.test_y = test_y
        self.checkpoint_path = checkpoint_path
        self.results_dir = results_dir
        self.img_height = img_height
        self.img_width = img_width
        self.seed = seed

        # Seeding
        seeding(self.seed)

        # Create results directory if not exists
        os.makedirs(self.results_dir, exist_ok=True)
        print(f"Directory created or already exists: {self.results_dir}")

        # Set device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(self.device)

        # Build model
        self.model = build_unet()
        self.model = self.model.to(self.device)
        self.model.load_state_dict(torch.load(self.checkpoint_path, map_location=self.device))
        self.model.eval()

        # Initialize metrics
        self.metrics_score = [0.0, 0.0, 0.0, 0.0, 0.0]
        self.confusion_matrix_score = [0.0, 0.0, 0.0, 0.0]
        self.time_taken = []
        self.auc_calculator = AUCCalculator()

    def evaluate(self):
        for i, (x, y) in tqdm(enumerate(zip(self.test_x, self.test_y)), total=len(self.test_x)):
            # Extract the name
            name = os.path.basename(x).split(".")[0]
            print(f"Extracted name: {name}")

            # Reading image
            image = cv2.imread(x, cv2.IMREAD_COLOR)
            x = np.transpose(image, (2, 0, 1)) / 255.0
            x = np.expand_dims(x, axis=0).astype(np.float32)
            x = torch.from_numpy(x).to(self.device)

            # Reading mask
            mask = cv2.imread(y, cv2.IMREAD_GRAYSCALE)
            y = np.expand_dims(mask, axis=0) / 255.0
            y = np.expand_dims(y, axis=0).astype(np.float32)
            y = torch.from_numpy(y).to(self.device)

            with torch.no_grad():
                # Prediction and Calculating FPS
                start_time = time.time()
                pred_y = self.model(x)
                pred_y = torch.sigmoid(pred_y)
                total_time = time.time() - start_time
                self.time_taken.append(total_time)

                # Calculate metrics
                score1 = calculate_metrics(y, pred_y)
                self.metrics_score = list(map(add, self.metrics_score, score1))
                score2 = calculate_confusion_matrix(y, pred_y)
                self.confusion_matrix_score = list(map(add, self.confusion_matrix_score, score2))
                self.auc_calculator.add_predictions(y, pred_y)

                # Prepare and save prediction mask
                pred_y = pred_y[0].cpu().numpy()  # (1, H, W)
                pred_y = np.squeeze(pred_y, axis=0)  # (H, W)
                pred_y = (pred_y > 0.5).astype(np.uint8)

            # Saving masks
            ori_mask = mask_parse(mask.cpu().numpy())
            pred_y = mask_parse(pred_y)
            line = np.ones((self.img_width, 10, 3)) * 128
            cat_images = np.concatenate([image, line, ori_mask, line, pred_y * 255], axis=1)

            pred_mask_path = os.path.join(self.results_dir, "pred_mask")
            os.makedirs(pred_mask_path, exist_ok=True)
            pred_mask_output_path = os.path.join(pred_mask_path, f"{name}_pred_mask.png")
            print(f"Saving predicted mask to: {pred_mask_output_path}")
            try:
                cv2.imwrite(pred_mask_output_path, pred_y * 255)  # Save the predicted mask as a binary image (0 or 255)
                print(f"Predicted mask successfully saved at: {pred_mask_output_path}")
            except Exception as e:
                print(f"Failed to save predicted mask at: {pred_mask_output_path}, Error: {e}")


            output_path = os.path.join(pred_mask_path, f"{name}.png")
            print(f"Saving to: {output_path}")

            if cv2.imwrite(output_path, cat_images):
                print(f"Image successfully saved at: {output_path}")
            else:
                print(f"Failed to save image at: {output_path}")

        # Calculate overall metrics
        self.calculate_overall_metrics()
        self.plot_roc_curve()

    def calculate_overall_metrics(self):
        jaccard = self.metrics_score[0] / len(self.test_x)
        f1 = self.metrics_score[1] / len(self.test_x)
        recall = self.metrics_score[2] / len(self.test_x)
        precision = self.metrics_score[3] / len(self.test_x)
        acc = self.metrics_score[4] / len(self.test_x)
        sensitivity = self.confusion_matrix_score[0] / len(self.test_x)
        ppv = self.confusion_matrix_score[1] / len(self.test_x)
        specificity = self.confusion_matrix_score[2] / len(self.test_x)
        npv = self.confusion_matrix_score[3] / len(self.test_x)

        print(f"Jaccard: {jaccard:1.4f} - F1: {f1:1.4f} - Recall: {recall:1.4f} - Precision: {precision:1.4f} - Acc: {acc:1.4f} - Sensitivity: {sensitivity:1.4f} - PPV: {ppv:1.4f} - Specificity: {specificity:1.4f} - NPV: {npv:1.4f}")
        fps = 1 / np.mean(self.time_taken)
        print("FPS: ", fps)

    def plot_roc_curve(self):
        # Calculate and plot ROC curve
        auc = self.auc_calculator.calculate_auc()
        print(f"Overall AUC: {auc:.4f}")
        roc_output_path = os.path.join(self.results_dir, "roc_curve", "overall_roc.png")
        os.makedirs(os.path.dirname(roc_output_path), exist_ok=True)
        self.auc_calculator.plot_roc_curve(output_path=roc_output_path)

if __name__ == "__main__":
    # Set parameters
    excel_path = r"E:\DeepLearning\Session_1_seg_for_od\S2_results\data_with_split.xlsx"
    checkpoint_path = r"E:\DeepLearning\Session_1_seg_for_od\S2_results\results\checkpoint.pth"
    results_dir = r"E:\DeepLearning\Session_1_seg_for_od\S2_results\results"
    img_height = 512
    img_width = 512
    seed = 42

    # Load dataset split information
    df = pd.read_excel(excel_path)
    test_df = df[df['dataset'] == 'test']
    test_x = test_df['new_image_path'].tolist()
    test_y = test_df['new_mask_path'].tolist()

    # Initialize and evaluate model
    evaluator = UNetEvaluator(test_x, test_y, checkpoint_path, results_dir, img_height, img_width, seed)
    evaluator.evaluate()