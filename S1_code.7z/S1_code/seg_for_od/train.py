import os
import sys

# Set the working directory to the parent directory containing your modules
working_directory = r"E:\DeepLearning\Session_1_seg_for_od\S1_code\seg_for_od"
sys.path.append(working_directory)
os.chdir(working_directory)

import time
import torch
import pandas as pd
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
from dataset import DriveDataset
from model import build_unet
from utils import seeding, epoch_time, train, evaluate, DiceBCELoss

class UNetTrainer:
    def __init__(self, excel_path, output_excel_path, checkpoint_path, batch_size, lr, num_epochs, img_height, img_width, num_workers, seed):
        # Set parameters
        self.excel_path = excel_path
        self.output_excel_path = output_excel_path
        self.checkpoint_path = checkpoint_path
        self.batch_size = batch_size
        self.lr = lr
        self.num_epochs = num_epochs
        self.img_height = img_height
        self.img_width = img_width
        self.num_workers = num_workers
        self.seed = seed

        # Seeding
        seeding(self.seed)

        # Load dataset from Excel file
        self.df = pd.read_excel(self.excel_path)

        # Extract image and mask paths
        self.image_paths = self.df['new_image_path'].tolist()
        self.mask_paths = self.df['new_mask_path'].tolist()

        # Split dataset into training, validation, and test sets
        train_x, temp_x, train_y, temp_y = train_test_split(self.image_paths, self.mask_paths, test_size=0.3, random_state=self.seed)
        valid_x, test_x, valid_y, test_y = train_test_split(temp_x, temp_y, test_size=1/3, random_state=self.seed)

        # Add dataset split information to DataFrame
        self.df['dataset'] = ''
        self.df.loc[self.df['new_image_path'].isin(train_x), 'dataset'] = 'train'
        self.df.loc[self.df['new_image_path'].isin(valid_x), 'dataset'] = 'validation'
        self.df.loc[self.df['new_image_path'].isin(test_x), 'dataset'] = 'test'

        # Save updated DataFrame with dataset split information
        self.df.to_excel(self.output_excel_path, index=False)

        # Print dataset split sizes
        print(f"Dataset Size:\nTrain: {len(train_x)} - Valid: {len(valid_x)} - Test: {len(test_x)}")

        # Create datasets and data loaders
        self.train_dataset = DriveDataset(train_x, train_y)
        self.valid_dataset = DriveDataset(valid_x, valid_y)

        self.train_loader = DataLoader(dataset=self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)
        self.valid_loader = DataLoader(dataset=self.valid_dataset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

        # Set device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(self.device)

        # Build model
        self.model = build_unet()
        self.model = self.model.to(self.device)
        print(next(self.model.parameters()).device)

        # Set optimizer, scheduler, and loss function
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, 'min', patience=5)
        self.loss_fn = DiceBCELoss()

        self.best_valid_loss = float("inf")

    def train_model(self):
        for epoch in range(self.num_epochs):
            start_time = time.time()

            train_loss = train(self.model, self.train_loader, self.optimizer, self.loss_fn, self.device)
            valid_loss = evaluate(self.model, self.valid_loader, self.loss_fn, self.device)

            # Save model checkpoint if validation loss improves
            if valid_loss < self.best_valid_loss:
                print(f"Valid loss improved from {self.best_valid_loss:2.4f} to {valid_loss:2.4f}. Saving checkpoint: {self.checkpoint_path}")
                self.best_valid_loss = valid_loss
                torch.save(self.model.state_dict(), self.checkpoint_path)

            end_time = time.time()
            epoch_mins, epoch_secs = epoch_time(start_time, end_time)

            # Print epoch statistics
            print(f'Epoch: {epoch+1:02} | Epoch Time: {epoch_mins}m {epoch_secs}s')
            print(f'	Train Loss: {train_loss:.3f}')
            print(f'	Val. Loss: {valid_loss:.3f}')

if __name__ == "__main__":
    # Set parameters
    excel_path = r"E:\DeepLearning\Session_1_seg_for_od\S0_data\P1_data\processed_data_summary.xlsx"
    output_excel_path = r"E:\DeepLearning\Session_1_seg_for_od\S2_results\data_with_split.xlsx"
    checkpoint_path = r"E:\DeepLearning\Session_1_seg_for_od\S2_results\results\checkpoint.pth"
    batch_size = 16
    lr = 1e-4
    num_epochs = 10
    img_height = 512
    img_width = 512
    num_workers = 4
    seed = 42

    # Initialize and train model
    trainer = UNetTrainer(excel_path, output_excel_path, checkpoint_path, batch_size, lr, num_epochs, img_height, img_width, num_workers, seed)
    trainer.train_model()